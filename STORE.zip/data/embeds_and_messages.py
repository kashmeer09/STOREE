import discord

def purchase_log_embed(user, product, product_id, price):
    embed = discord.Embed(title="Purchase Log", color=0x00ff00)
    embed.add_field(name="User", value=user.mention, inline=False)
    embed.add_field(name="Product ID", value=product_id, inline=True)
    embed.add_field(name="Product Name", value=product['name'], inline=True)
    embed.add_field(name="Price", value=f"${price:.2f}", inline=True)
    return embed

def insufficient_balance_message(user):
    return f"{user.mention}, you do not have enough balance to make this purchase."

def product_not_found_message():
    return "Product not found."

def thank_you_message(product_name):
    return f"Thank you for purchasing **{product_name}**!"

def file_not_available_message(user, product_name):
    return f"{user.mention}, the file for **{product_name}** is currently not available."

def user_new_balance_message(user, new_balance):
    return f"{user.mention}, your new balance is ${new_balance:.2f}."

def user_balance_message(user, balance):
    return f"{user.mention}, your current balance is ${balance:.2f}."

def no_permission_message(user):
    return f"{user.mention}, you do not have permission to use this command."

def cannot_respond_dm_message():
    return "I cannot respond to DMs from this user."